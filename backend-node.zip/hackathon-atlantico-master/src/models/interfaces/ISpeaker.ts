export default interface ISpeaker {
  _id: string
  name: string
  profession: string
  additional_info: string
  phone: string
  email: string
  createdAt: Date
}