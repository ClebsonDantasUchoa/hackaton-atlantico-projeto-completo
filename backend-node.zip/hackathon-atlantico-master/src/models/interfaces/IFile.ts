export default interface IFile {
  _id: string
  lecture_id: string
  url: string
  status: string
  createdAt?: Date
}