export default interface IUser {
	_id: string
	email: string
	name: string
	password: string
	createdAt: Date
}
