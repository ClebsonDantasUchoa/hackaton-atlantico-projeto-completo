export default interface IAudioPayload {
    lecture_id: string
    baseAudio: string
}