<template>
    <v-app-bar app>
      <v-toolbar-title class="headline text-uppercase">
        <span>DEMO APP</span>
        <span class="font-weight-light">DEMO APP</span>
      </v-toolbar-title>
      <v-spacer></v-spacer>
    </v-app-bar>
</template>